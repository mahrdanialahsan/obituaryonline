

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Pages</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Pages</li>
    </ol>
    <div class="card-header">
        <div class="row">
            <div class="col-12 text-right" style="text-align: right">
                <a class="btn btn-sm btn-dark" href="<?php echo e(route('admin.page.create')); ?>">New Page</a>
            </div>
        </div>
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                <tr>
                    <th>No#</th>
                    <th>Page Title</th>
                    <th>Slug</th>
                    <th>Type</th>
                    <th>Thumbnail</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($row->title); ?></td>
                        <td><?php echo e($row->slug); ?></td>
                        <td><?php echo e(ucfirst($row->type)); ?></td>
                        <td><img height="50" src="<?php echo e(file_exists(storage_path('app/public/pages/'.$row->thumbnail_image)) ?  url('storage/pages/'.$row->thumbnail_image): asset('images/12.jpg')); ?>"></td>
                        <td>
                            <a class="btn btn-sm btn-dark"  href="<?php echo e(route('admin.page.show',['id'=>$row->id])); ?>">Edit</a>
                            <?php if($row->type == 'blog'): ?>
                                <a class="btn btn-sm btn-danger" href="<?php echo e(route('admin.page.delete',['id'=>$row->id])); ?>">Delete</a>
                            <?php endif; ?>
                       </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\DEMO\arbituary\laravel\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>