

<?php $__env->startSection('content'); ?>
    <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
    <h1 class="mt-4">Relation Types</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Relation Types</li>
    </ol>
    <div class="card mb-4">
        <div class="card-body">
            <form id="site-form" method="post" action="<?php echo e(@$relationtype->id >0 ? route('admin.relationtype.update',['id'=>@$relationtype->id]):route('admin.relationtype.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <div class="col-md-12  mb-3">
                        <div class="form-floating mb-3 mb-md-0">
                            <input value="<?php echo e(Session::has('title') ? Session::get('title') : @$relationtype->title); ?>" class="form-control" id="title" name="title" type="text" placeholder="Title" required />
                            <label for="title">Title</label>
                        </div>
                    </div>






                </div>
                <div class="mt-4 mb-0">
                    <div class="d-grid"><button class="btn btn-primary btn-block" type="submit">Update</button></div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function () {
            $('#image').dropify({
                minWidth: 320,
                minHeight: 400
            });

        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\DEMO\arbituary\laravel\resources\views/admin/relationtypes/create.blade.php ENDPATH**/ ?>