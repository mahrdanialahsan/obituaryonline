

<?php $__env->startSection('content'); ?>
<h1 class="mt-4">Payments</h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
    <li class="breadcrumb-item active">Payments</li>
</ol>
<div class="card mb-4">
    <div class="card-body">
        <table id="datatablesSimple">
            <thead>
            <tr>
                <th>Piad By</th>
                <th>Tran ID</th>
                <th>Amount</th>
                <th>receipt_url</th>
                <th>Created At</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row->user_name); ?></td>
                    <td><?php echo e($row->transaction_id); ?></td>
                    <td><?php echo e(number_format($row->amount,2)); ?>$</td>
                    <td><a target="_blank" href="<?php echo e($row->receipt_url); ?>">View</a></td>
                    <td><?php echo e(date('Y-m-d H:i:s', strtotime($row->created_at))); ?></td>
                    <td><a href="<?php echo e(route('admin.payments.show',['id'=>$row->id])); ?>">Details</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\DEMO\arbituary\laravel\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>