

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Obituaries</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Obituaries</li>
    </ol>
    <div class="card-header">
        <div class="row">
            <div class="col-6"><h4>Obituary Details</h4></div>
            <div class="col-6 text-right" style="text-align: right">
                <?php if($obituary->status == 0 ): ?>
                <a class="btn btn-sm btn-primary" href="<?php echo e(route('admin.obituary.approve',['id'=>$obituary->uid])); ?>">Accept</a>
                <a class="btn btn-sm btn-danger" href="<?php echo e(route('admin.obituary.reject',['id'=>$obituary->uid])); ?>">Reject</a>
                <?php endif; ?>
                <?php if($obituary->total_donation > $obituary->total_paid): ?>
                    <a class="btn btn-sm btn-dark" href="<?php echo e(route('admin.obituary.pay',['id' => $obituary->id ])); ?>">Release (<?php echo e(round($obituary->total_donation-$obituary->total_paid,2)); ?>$)</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th style="vertical-align: middle">Deceased Name</th>
                    <td><?php echo e($obituary->deceased_first_name); ?> <?php echo e($obituary->deceased_last_name); ?></td>
                    <th style="vertical-align: middle">Date of Birth</th>
                    <td><?php echo e(\Carbon\Carbon::parse($obituary->date_of_birth)->format('Y-m-d')); ?></td>
                </tr>
                <tr>
                    <th style="vertical-align: middle">Date of Death</th>
                    <td><?php echo e(\Carbon\Carbon::parse($obituary->date_of_death)->format('Y-m-d H:i')); ?></td>
                    <th style="vertical-align: middle">Wake Location</th>
                    <td><?php echo e($obituary->wake_location); ?></td>
                </tr>
                <tr>
                    <th style="vertical-align: middle">Wake Period </th>
                    <td><?php echo e($obituary->wake_period); ?></td>
                    <th style="vertical-align: middle">Funeral Date</th>
                    <td><?php echo e(\Carbon\Carbon::parse($obituary->funeral_date)->format('Y-m-d H:i')); ?></td>
                </tr>
                <tr>
                    <th style="vertical-align: middle">Funeral Location</th>
                    <td><?php echo e($obituary->funeral_location); ?></td>
                    <th style="vertical-align: middle">Default Amount</th>
                    <td><?php echo e($obituary->default_amount); ?>$</td>
                </tr>
                <tr>
                    <th style="vertical-align: middle">Total Donation</th>
                    <td><?php echo e($obituary->total_donation); ?>$</td>
                    <th style="vertical-align: middle">Total Paid</th>
                    <td><?php echo e($obituary->total_paid); ?>$</td>
                </tr>

                <tr>
                    <th style="vertical-align: middle">Status</th>
                    <td><?php echo e($obituary->status == 0 ? 'Pending':(    $obituary->status == 1 ? 'Approved': 'Deactivated'  )); ?></td>
                    <th style="vertical-align: middle">Deceased Picture</th>
                    <td>
                        <?php if(!is_null($obituary->deceased_picture) && $obituary->deceased_picture != ''): ?>
                            <img style="max-width: 100px;" src="<?php echo e(url('storage/deceased_picture/'.$obituary->deceased_picture)); ?>">
                        <?php else: ?>
                            NA
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th style="vertical-align: middle">Death Certificate</th>
                    <td>
                        <?php if(!is_null($obituary->death_certificate) && $obituary->death_certificate != ''): ?>
                            <a download href="<?php echo e(url('storage/death_certificate/'.$obituary->death_certificate)); ?>"> Download </a>
                        <?php else: ?>
                            NA
                        <?php endif; ?>
                    </td>
                    <th style="vertical-align: middle">Wills</th>
                    <td>
                        <?php if(!is_null($obituary->poa_wills) && $obituary->poa_wills != ''): ?>
                            <a download href="<?php echo e(url('storage/poa_wills/'.$obituary->poa_wills)); ?>"> Download </a>
                        <?php else: ?>
                            NA
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th style="vertical-align: middle">Bank Account Details</th>
                    <td colspan="3">
                        <table class="table table-bordered ">
                            <thead>
                            <tr>
                                <th style="vertical-align: middle">Bank Name</th>
                                <th style="vertical-align: middle">Account Title</th>
                                <th style="vertical-align: middle">Account Number</th>
                            </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($obituary->bank_name); ?></td>
                                    <td><?php echo e($obituary->account_title); ?></td>
                                    <td><?php echo e($obituary->account_number); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <?php
                    $surviving_family =    json_decode($obituary->surviving_family);
                ?>
                <?php if(is_array($surviving_family) || is_object($surviving_family)): ?>
                    <tr>
                        <th style="vertical-align: middle">Surviving Family</th>
                        <td colspan="3">
                            <table class="table table-bordered ">
                                <thead>
                                <tr>
                                    <th style="vertical-align: middle">Relation</th>
                                    <th style="vertical-align: middle">Name</th>
                                    <th style="vertical-align: middle">Description</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $surviving_family; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(getRelationType($row->surviving_family_relation_title)); ?></td>
                                        <td><?php echo e($row->surviving_family_relation_name); ?></td>
                                        <td>
                                            <?php if(trim($row->surviving_family_relation_description) != ''): ?>
                                                <p style="text-align: justify"><small><?php echo e($row->surviving_family_relation_description); ?></small></p>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                <?php endif; ?>

                <tr>
                    <th style="vertical-align: middle">About Obituary</th>
                    <td colspan="3"><?php echo $obituary->message; ?></td>
                </tr>
                </thead>
            </table>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <div class="row">
                <div class="col-12"><h4>Donations Details</h4></div>
            </div>
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <caption> </caption>
                <thead>
                <tr>
                    <th style="vertical-align: middle">Paid By</th>
                    <th style="vertical-align: middle">Amount</th>
                    <th style="vertical-align: middle">Created At</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($row->user_name); ?></td>
                        <td><?php echo e(number_format($row->amount,2)); ?>$</td>
                        <td><?php echo e(date('Y-m-d H:i:s', strtotime($row->created_at))); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


    <div class="card mb-4">
        <div class="card-header">
            <div class="row">
                <div class="col-12"><h4>Released Payment Details</h4></div>
            </div>
        </div>
        <div class="card-body">
            <table id="datatablesSimple1">
                <thead>
                <tr>
                    <th style="vertical-align: middle">Amount</th>
                    <th style="vertical-align: middle">Released At</th>
                    <th style="vertical-align: middle">Recipt</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $releasedpayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(number_format($row->amount,2)); ?>$</td>
                        <td><?php echo e(date('Y-m-d H:i:s', strtotime($row->created_at))); ?></td>
                        <td>
                            <?php if(!is_null($row->payment_recipt) && $row->payment_recipt != ''): ?>
                                <a download href="<?php echo e(url('storage/payment_recipt/'.$row->payment_recipt)); ?>"> Download </a>
                            <?php else: ?>
                                NA
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\DEMO\arbituary\laravel\resources\views/admin/obituaries/details.blade.php ENDPATH**/ ?>