<?php
    use Illuminate\Support\Facades\Route;
?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"  class="no-js no-svg">
<?php
    if(session()->has('cart_items') && array_sum(array_values(session()->get('cart_items'))) > 0){
        $cart           =   array_sum(array_values(session()->get('cart_items')));
        $shopping_cart = "<i class='fa fa-shopping-cart'></i> <sup class='badge bg-danger'><small>".$cart."$</small></sup>";
    }else{
        $shopping_cart = "<i class='fa fa-shopping-cart'></i>";
    }

?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <link rel="shortcut icon" href="<?php echo e(file_exists(storage_path('app/public/site_settings/'.$site->fav_icon)) ?  url('storage/site_settings/'.$site->fav_icon): asset('images/favicon.ico')); ?>" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($site->site_title ? $site->site_title:"Obituary Online."); ?></title>
    <meta name='robots' content='max-image-preview:large' />
    <?php if(in_array(Route::currentRouteName(),['obituary.details','about-us','contact-us','blogs','blog'])): ?>
    <?php echo $__env->yieldPushContent('meta'); ?>
    <?php else: ?>
    <meta property="og:url"           content="<?php echo e(url('/')); ?>" />
    <meta property="og:type"          content="website" />
    <meta property="og:title"         content="<?php echo e($site->site_title ? $site->site_title:"Obituary Online."); ?>" />
    <meta property="og:description"   content="<?php echo e($site->site_title ? $site->site_title:"Obituary Online."); ?>" />
    <meta property="og:image"         content="<?php echo e(file_exists(storage_path('app/public/site_settings/'.$site->site_logo)) ?  url('storage/site_settings/'.$site->site_logo): asset('images/logo.png')); ?>" />
    <?php endif; ?>
    <link rel='dns-prefetch'    href="<?php echo e(asset('http://fonts.googleapis.com/')); ?>" />
    <link rel='stylesheet'      id='wp-block-library-css'       href="<?php echo e(asset('css/style.min6a4d.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      id='font-awesome-css'           href="<?php echo e(asset('css/font-awesome.min1849.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      id='flaticon-css'               href="<?php echo e(asset('css/flaticon6a4d.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      id='owl-css'                    href="<?php echo e(asset('css/owl6a4d.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      id='swiper-css'                 href="<?php echo e(asset('css/swiper.min6a4d.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      id='bootstrap-css'              href="<?php echo e(asset('css/bootstrap6a4d.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      type='text/css' media='all'     href="<?php echo e(asset('css/bootstrap-datetimepicker.min.css')); ?>"  />
    <link rel='stylesheet'      id='color-css'                  href="<?php echo e(asset('css/color6a4d.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      id='purehearts-main-style-css'  href="<?php echo e(asset('css/style6a4d.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      id='purehearts-custom-css'      href="<?php echo e(asset('css/custom6a4d.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      id='purehearts-responsive-css'  href="<?php echo e(asset('css/responsive6a4d.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      href="<?php echo e(asset('css/woocommerce6a4d.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      href="<?php echo e(asset('css/mt_main.css')); ?>" type='text/css' media='all' />
    <link rel='stylesheet'      href="<?php echo e(asset('css/mainfb9c.css')); ?>" type='text/css' media='all' />
    <link class="lfr-css-file"  href="<?php echo e(asset('css/aui.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel='stylesheet'      href="<?php echo e(asset('css/dropify.min.css')); ?>" type="text/css" />
    <link rel='stylesheet'      href="<?php echo e(asset('toast/toast.style.css')); ?>" type="text/css" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <style id="charitable-highlight-colour-styles">.obituary-raised .amount,.obituary-figures .amount,.donors-count,.time-left,.charitable-form-field a:not(.button),.charitable-form-fields .charitable-fieldset a:not(.button),.charitable-notice,.charitable-notice .errors a { color:#f89d35; }.obituary-progress-bar .bar,.donate-button,.charitable-donation-form .donation-amount.selected,.charitable-donation-amount-form .donation-amount.selected { background-color:#f89d35; }.charitable-donation-form .donation-amount.selected,.charitable-donation-amount-form .donation-amount.selected,.charitable-notice,.charitable-drag-drop-images li:hover a.remove-image,.supports-drag-drop .charitable-drag-drop-dropzone.drag-over { border-color:#f89d35; }</style>
    <style>
        .case-block-two .inner-box .lower-content .info-box li {
            padding-left: 0px !important;
        }
        .mt-1{
            margin-top: 1px;
        }
        .mt-2{
             margin-top: 2px;
         }
        .mt-3{
            margin-top: 3px;
        }
        .mt-4{
            margin-top: 4px;
        }
        .mt-5{
            margin-top: 5px;
        }
        .mt-10{
            margin-top: 10px;
        }
        .mt-15{
            margin-top: 15px;
        }
        .mt-20{
            margin-top: 20px;
        }


        .mb-1{
            margin-bottom: 1px;
        }
        .mb-2{
            margin-bottom: 2px;
        }
        .mb-3{
            margin-bottom: 3px;
        }
        .mb-4{
            margin-bottom: 4px;
        }
        .mb-5{
            margin-bottom: 5px;
        }
        .mb-10{
            margin-bottom: 10px;
        }
        .mb-15{
            margin-bottom: 15px;
        }
        .mb-20{
            margin-bottom: 20px;
        }
        input {
            padding-left: 14px;
        }
        .dropdown-item {
            text-align: center !important;
        }
        .bg-danger small{
            color: #fff;
        }
        .footer-card li a:hover{
            color: #fff !important;

        }
        .main-menu .navigation > li {
            margin: 0px 10px;
        }
        @media  screen and (min-width: 769px) {
            .header-style-two .header-lower .outer-container {
                padding: 0px 10px 0px 95px !important;
            }
        }
    </style>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body class="page-template">
    <div class="boxed_wrapper red-color">

        <!-- main header -->

        <header class="main-header header-style-two">
            <!-- logo-box -->
            <div class="logo-box">
                <div class="shape" style="background-image: url(<?php echo e(asset('images/shape-30.png')); ?>);"></div>
                <figure class="logo"><a href="<?php echo e(url('/')); ?>" title="Arbituaryonline">
                        <img src="<?php echo e(file_exists(storage_path('app/public/site_settings/'.$site->site_logo)) ?  url('storage/site_settings/'.$site->site_logo): asset('images/logo.png')); ?>" alt="logo" style="height: 86px;" />
                    </a>
                </figure>
            </div>
            <!-- header -->
            <div class="header-lower">
                <div class="outer-container">
                    <div class="outer-box">
                        <div class="logo-box responsive">
                            <div class="shape" style="background-image: url(<?php echo e(asset('images/shape-30.png')); ?>);"></div>
                            <figure class="logo"><a href="<?php echo e(url('/')); ?>" title="Arbituaryonline">
                                    <img src="<?php echo e(file_exists(storage_path('app/public/site_settings/'.$site->site_logo)) ?  url('storage/site_settings/'.$site->site_logo): asset('images/logo.png')); ?>" alt="logo" style="height: 86px;" />
                                </a>
                            </figure>
                        </div>
                        <div class="menu-area clearfix">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">

                                        <li  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-837">
                                            <a title="Home" href="<?php echo e(route('home')); ?>" class="hvr-underline-from-left1"><?php echo e($site->home_page_menu_title ? $site->home_page_menu_title:"Today's Obituary"); ?></a>
                                        </li>



                                        <li  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-837">
                                            <a title="Post obituary" href="<?php echo e(route('obituary.create')); ?>" class="hvr-underline-from-left1"><?php echo e($site->obituary_page_menu_title ? $site->obituary_page_menu_title:"Post obituary"); ?></a>
                                        </li>
                                        <li  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-837">
                                            <a title="Post obituary" href="<?php echo e(route('obituaries')); ?>" class="hvr-underline-from-left1">Archives</a>
                                        </li>
                                        <li  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-837">
                                            <a title="Post obituary" href="<?php echo e(route('learn')); ?>" class="hvr-underline-from-left1">Learn</a>
                                        </li>
                                        <li  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-837">
                                            <a title="Post obituary" href="<?php echo e(route('contact-us')); ?>" class="hvr-underline-from-left1">Contact Us</a>
                                        </li>
                                        <li  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-837">
                                            <a title="Post obituary" href="<?php echo e(route('about-us')); ?>" class="hvr-underline-from-left1">About Us</a>
                                        </li>
                                        <li  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-837">
                                            <a title="Post obituary" href="<?php echo e(route('blogs')); ?>" class="hvr-underline-from-left1">Blog</a>
                                        </li>

                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="nav-right-content clearfix">
                            <?php if( @Auth()->user()->is_admin != 1): ?>
                            <div class="search-box-outer">
                                <div class="dropdown">
                                    <button class="search-box-btn" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-search"></i></button>
                                    <div class="dropdown-menu search-panel" aria-labelledby="dropdownMenu3">
                                        <div class="form-container">
                                            <form id="g_search-form-1" method="get" action="<?php echo e(route('search')); ?>">
                                                <div class="form-group">
                                                    <input type="search" id="g_search-1" name="q" value="" placeholder="Search...." required="">
                                                    <button type="button" btn-id="1" class="search-btn g-search-btn"><span class="fa fa-search"></span></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <div class="admin clearfix">
                                <?php if(auth()->guard()->guest()): ?>
                                    <a href="<?php echo e(route('login')); ?>"><i class="admin-bar"></i><?php echo e($site->login_page_menu_title ? $site->login_page_menu_title:'Log In'); ?></a> |
                                    <a href="<?php echo e(route('register')); ?>"><i class="admin-bar"></i><?php echo e($site->signup_page_menu_title ? $site->signup_page_menu_title:'Sign Up'); ?></a>
                                <?php else: ?>
                                    <?php echo e(Auth::user()->name); ?> |
                                    <a href="<?php echo e(route('mine')); ?>"> <?php echo e($site->my_obituaries_title ? $site->my_obituaries_title:"My Obituaries"); ?> </a> |
                                    <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                        <i class="admin-bar"></i> <?php echo e(__('Logout')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="menu-area clearfix">
                            <nav class="main-menu clearfix">
                            </nav>
                        </div>
                        <div class="nav-right-content clearfix">
                            <?php if( @Auth()->user()->is_admin != 1): ?>
                            <div class="search-box-outer">
                                <div class="dropdown">
                                    <button class="search-box-btn" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="icon-search"></i></button>
                                    <div class="dropdown-menu search-panel" aria-labelledby="dropdownMenu3">
                                        <div class="form-container">
                                            <form id="g_search-form-2" method="get" action="<?php echo e(route('search')); ?>">
                                                <div class="form-group">
                                                    <input type="search" id="g_search-2" name="q" value="" placeholder="Search...." required="">
                                                    <button type="button" btn-id="2" class="search-btn g-search-btn"><span class="fa fa-search"></span></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <div class="admin clearfix">
                                <?php if(auth()->guard()->guest()): ?>
                                    <a href="<?php echo e(route('login')); ?>"><i class="admin-bar"></i><?php echo e($site->login_page_menu_title ? $site->login_page_menu_title:'Log In'); ?></a> |
                                    <a href="<?php echo e(route('register')); ?>"><i class="admin-bar"></i><?php echo e($site->signup_page_menu_title ? $site->signup_page_menu_title:'Sign Up'); ?></a>
                                <?php else: ?>
                                    <?php echo e(Auth::user()->name); ?> |
                                    <a href="<?php echo e(route('mine')); ?>">  <?php echo e($site->my_obituaries_title ? $site->my_obituaries_title:"My Obituaries"); ?>  </a> |
                                    <a href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                        <i class="admin-bar"></i> <?php echo e(__('Logout')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </header>

        <!-- main-header end -->
        <!-- Mobile Menu  -->

        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fa fa-times"></i></div>

            <nav class="menu-box">
                <div class="nav-logo"><a href="#" title="Purehearts"><img src="<?php echo e(file_exists(storage_path('app/public/site_settings/'.$site->site_logo)) ?  url('storage/site_settings/'.$site->site_logo): asset('images/logo.png')); ?>" alt="logo"/></a></div>
                <div class="menu-outer"></div>


                <div class="social-links">
                    <?php if( @Auth()->user()->is_admin != 1): ?>
                    <ul class="clearfix">
                        <li>
                            <form id="g_search-form-3" method="get" action="<?php echo e(route('search')); ?>">
                                <div class="form-group">
                                    <div class="input-group mb-3" style="width: 250px; float: right">
                                        <input type="search" id="g_search-3" name="q" value="" placeholder="Search...." class="form-control"  aria-describedby="button-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary btn-dark g-search-btn" btn-id="3" type="button" id="button-addon2"><span class="fa fa-search"></span></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </li>



                        <?php if(auth()->guard()->guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>"><i class="admin-bar"></i><?php echo e($site->login_page_menu_title ? $site->login_page_menu_title:'Log In'); ?></a> </li>
                            <li><a href="<?php echo e(route('register')); ?>"><i class="admin-bar"></i><?php echo e($site->signup_page_menu_title ? $site->signup_page_menu_title:'Sign Up'); ?></a></li>
                        <?php else: ?>
                            <li> <?php echo e(Auth::user()->name); ?> </li>
                            <li><a href="<?php echo e(route('mine')); ?>">  <?php echo e($site->my_obituaries_title ? $site->my_obituaries_title:"My Obituaries"); ?> </a> </li>
                            <li><a href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="admin-bar"></i> <?php echo e(__('Logout')); ?>

                                </a></li>
                        <?php endif; ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </nav>
        </div>

        <!-- End Mobile Menu -->

        <?php echo $__env->yieldContent('content'); ?>

        <section class="elementor-section">
            <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-column">
                    <div class="elementor-widget-wrap elementor-element-populated">
                        <div class="elementor-element">
                            <div class="elementor-widget-container">

                                <!-- subscribe-section -->
                                <section class="subscribe-section ">
                                    <div class="bg-layer"></div>
                                    <div class="auto-container">
                                        <div class="inner-box clearfix">
                                            <div class="left-column pull-left">
                                                <div class="logo-box">
                                                    <div class="shape" style="background-image: url(<?php echo e(asset('images/shape-1.png')); ?>);"></div>
                                                    <figure class="logo"><a href="<?php echo e(url('/')); ?>"><img decoding="async" src="<?php echo e(file_exists(storage_path('app/public/site_settings/'.$site->site_logo)) ?  url('storage/site_settings/'.$site->site_logo): asset('images/logo.png')); ?>" alt="Awesome Image"></a></figure>
                                                </div>
                                                <div class="text">
                                                    <h3><i class="icon-email-open-sketched-envelope"></i>Subscribe <br> Our Newsletter</h3>
                                                </div>
                                            </div>
                                            <div class="right-column pull-right clearfix">
                                                <div class="form-inner">
                                                    <div class="subscribe-form">
                                                        <form id="subscription-form" class="mc4wp-form mc4wp-form-255" method="POST" action="<?php echo e(route('subscribe')); ?>" >
                                                            <?php echo csrf_field(); ?>
                                                            <div class="mc4wp-form-fields">
                                                                <div class="form-group">
                                                                    <input type="email" name="email" id="subscription-email" placeholder="Email address" required="">
                                                                    <button type="button" onclick="submitForm('subscription-form')">Get Our Email</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                                <ul class="social-style-one clearfix">
                                                    <li><a href="<?php echo e($site->facebook_url ? $site->facebook_url:"https://www.facebook.com/"); ?>"><i class="fa-brands fa-facebook-f"></i></a></li>
                                                    <li><a href="<?php echo e($site->twitter_url ? $site->twitter_url:"https://www.twitter.com/"); ?>"><i class="fa-brands fa-twitter"></i></a></li>
                                                    <li><a href="<?php echo e($site->linkedin_url ? $site->linkedin_url:"https://www.linkedin.com/"); ?>"><i class="fa-brands fa-linkedin"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <!-- subscribe-section end -->

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- main-footer -->

        <div class="footer-bottom">
            <div class="auto-container">
                <div class="inner-box clearfix">
                    <div class="copyright pull-left">
                        <p>© 2023 <a href="<?php echo e(route('home')); ?>"><?php echo e($site->site_title ? $site->site_title:"Obituary Online."); ?>,</a> <?php echo e($site->footer_rights ? $site->footer_rights:"All Rights Reserved."); ?></p>
                    </div>
                    <ul class="footer-card pull-right clearfix">
                        <li> <a title="Home" href="<?php echo e(route('home')); ?>" ><?php echo e($site->home_page_menu_title ? $site->home_page_menu_title:"Today's Obituary"); ?></a></li>
                        <li><a title="Post obituary" href="<?php echo e(route('obituary.create')); ?>" ><?php echo e($site->obituary_page_menu_title ? $site->obituary_page_menu_title:"Post obituary"); ?></a></li>
                        <li><a title="Post obituary" href="<?php echo e(route('obituaries')); ?>" >Archives</a></li>
                        <li><a title="Post obituary" href="<?php echo e(route('learn')); ?>" >Learn</a></li>
                        <li><a title="Post obituary" href="<?php echo e(route('contact-us')); ?>" >Contact Us</a></li>
                        <li><a title="Post obituary" href="<?php echo e(route('about-us')); ?>" >About Us</a></li>
                        <li> <a title="Post obituary" href="<?php echo e(route('blogs')); ?>" >Blog</a></li>






                    </ul>
                </div>
            </div>
        </div>

        <button class="scroll-top scroll-to-target" data-target="html">
            <i class="fa fa-long-arrow-up"></i>
        </button>

    </div>




    <!-- The Modal -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <button style="top: 4%;left: 45%;position: relative;" type="button" class="close" data-dismiss="modal">&times;</button>
                <!-- Modal body -->
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12 text-center mt-10">
                            Yes, I want to donate
                        </div>
                        <div class="col-12 text-center mt-10">
                            <div class="dropdown">
                                <button class="btn" style="color: #6BC1CC" type="button" id="dropdownMenuButton"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Select  <i class="fa fa-caret-down"></i>
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <span class="dropdown-nchor-list">
                                        <button type="button" class="dropdown-item ">10</button>
                                        <button type="button" class="dropdown-item ">20</button>
                                        <button type="button" class="dropdown-item ">30</button>
                                        <button type="button" class="dropdown-item ">40</button>
                                    </span>
                                    <hr style="margin: 1px !important;">
                                    <div class="row" style="width: 185px;text-align: center;padding: 8px;">
                                        <div class="col-12"><small>Enter your own amount</small></div>
                                        <div class="col-12"><input type="number" id="dropdown_custom_amount" style="height: 35px"></div>
                                        <div class="col-12"><button class="btn btn-sm button text-center dropdown_custom_btn " style="line-height: 1px">select</button></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 text-center">
                            <h2 class="donate-now-title"></h2>
                        </div>
                        <div class="col-12 text-center">
                            <hr style="margin: 0px">
                        </div>
                        <div class="col-12 text-center">
                            You've met the minimum tax deduction amount set by the organisation.
                        </div>
                    </div>
                    <div class="row mb-20">
                        <div class="col-12 text-center mt-10">
                            <button type="button" data-cart-btn="cart" class="btn-ghost clearfix  impact-message button donate-popup-button " id="user-input-holder"> Add To Cart <i class="fa fa-shopping-cart"></i> </button>
                        </div>
                        <div class="col-12 text-center mt-10">
                            <button type="button" data-cart-btn="donate" class="btn-ghost clearfix  impact-message button donate-popup-button" id="user-input-holder"> DONATE TODAY </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/loadingoverlay.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min431f.js')); ?>"></script>
    <script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/moment-duration-format.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min431f.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/owl431f.js')); ?>"></script>
    <script src="<?php echo e(asset('js/swiper.min48f5.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wow431f.js')); ?>"></script>
    <script src="<?php echo e(asset('js/appear431f.js')); ?>"></script>
    <script src="<?php echo e(asset('js/scrollbar431f.js')); ?>"></script>
    <script src="<?php echo e(asset('js/script6a4d.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dropify.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('toast/toast.script.js')); ?>"></script>


    <script>
        let relationtypes = [];
        function getRelationType(id){
            return relationtypes.find(x=>(x.id==id))?.title || '';
        }

        function loadRelationType(id=0){
            let options =   `<option value="">Select Relation</option>`;
            if(relationtypes.length){
                relationtypes.forEach(x=>{
                    options +=   `<option ${x.id==id ? 'selected':''} value="${x.id}">${x.title}</option>`;
                })
            }
            return options;
        }
        $.ajax({
            type        : 'GET', // define the type of HTTP verb we want to use (POST for our form)
            url         : `/get-relation-types`,
            processData : false,
            contentType : false,
            cache       : false,
            headers     : {
                'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
            },
            success: function (response) {
                if(response.status == 'success'){
                    relationtypes   =   response.data;
                }else{
                    toaster('Error',response.msg,'error');
                }
            },
            error: function (data) {
                toaster('Error',data.responseJSON.message,'error');
            }
        })
        $.LoadingOverlay("show");
        $(document).on('click','.donate-popup-button',function () {
             let btn_type   =  $(this).attr('data-cart-btn');
             let uid        =  $(this).attr('uid');
             //alert(uid);
             let amount     =  parseInt($('#dropdownMenuButton').attr('amount'));
             if(amount > 0){
                 $.ajax({
                     type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
                     url         : `/add-to-cart/${uid}/amount/${amount}`, // the url where we want to POST
                     data        : {},
                     processData : false,
                     contentType : false,
                     cache       : false,
                     headers     : {
                         'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                     },
                     success: function (response) {
                         if(response.status == 'success'){
                             if(response.amount > 0){
                                 $('.cart-items').html(`<i class="fa-brands fa-shopping-cart"></i> <sup class="badge bg-danger"><small>${response.amount}$</small></sup>`)
                             }else{
                                 $('.cart-items').html(`<i class="fa-brands fa-shopping-cart"></i></span>`)
                             }
                             if(btn_type == 'donate'){
                                 window.location = '/cart/donation';
                             }else{
                                 $('.modal').modal('hide')
                                 toaster('Success','Item added to cart.','success');
                             }

                         }else{
                             toaster('Error',response.msg,'error');
                         }
                     },
                     error: function (data) {
                         toaster('Error',data.responseJSON.message,'error');
                     }
                 })
             }else{
                 toaster('Error','Please select amount.','error');
             }

        });
        $(document).on('click','.g-search-btn',function () {
            var btn_id = $(this).attr('btn-id');
             if($.trim($(`#g_search-${btn_id}`).val()) != ''){
                $(`#g_search-form-${btn_id}`).submit();
             }
        });
        $(document).on('click','.dropdown-menu .dropdown-item',function(){
            let selText = $(this).text();
            $('#dropdownMenuButton').attr('amount',selText)
            $(this).parents('.dropdown').find('#dropdownMenuButton').html(`<span style="margin-right: 20px;font-size: 20px">${selText} </span>  dollars <i class="fa fa-caret-down"></i>`);
        });
        $(document).on('click','.dropdown_custom_btn',function(){
            let selText = $('#dropdown_custom_amount').val();
            $('.dropdown-nchor-list').append(`<button type="button"  class="dropdown-item">${selText}</button>`);
            $('#dropdownMenuButton').html(`<span style="margin-right: 20px;font-size: 20px">${selText} </span>  dollars <i class="fa fa-caret-down"></i>`);
            $('#dropdownMenuButton').attr('amount',selText)
            $('#dropdown_custom_amount').val('');
        });
        $(document).on('click','.triggerDonateNow',function(){
            $('.donate-now-title').text($(this).attr('title'));
            $('#dropdownMenuButton').html(` Select  <i class="fa fa-caret-down"></i>`);
            $('.donate-popup-button').attr('uid',$(this).attr('uid'));
            $('#myModal').modal({backdrop: 'static', keyboard: false}, 'show');
        });
        function toaster(title="test",message="this is a test message.",type="success"){
            $.Toast(title, message,type, {
                has_icon:true,
                has_close_btn:true,
                stack: true,
                fullscreen:false,
                timeout:8000,
                sticky:true,
                has_progress:true,
                //position_class:'toast-top-center',
                border_radius: 6,
                //width:100,
                rtl:false,
            });
        }
        function submitForm(form_id,action_url=null){
            var form = $(`#${form_id}`)[0];
            var data = new FormData(form);
            $.ajax({
                type        : $(`#${form_id}`).attr('method'), // define the type of HTTP verb we want to use (POST for our form)
                url         : action_url == null ? $(`#${form_id}`).attr('action'):action_url, // the url where we want to POST
                enctype     : 'multipart/form-data',
                data        : data,
                processData : false,
                contentType : false,
                cache       : false,
                headers     : {
                    'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                },
                success: function (data) {
                    if(data.status == 'success'){
                        if(form_id == 'subscription-form'){
                            $('#subscription-email').val('');
                        }
                        toaster('Success',data.msg,'success');
                    }
                    else if(data.status == 'redirect'){
                        toaster('Success',data.msg,'success');
                        window.location = data.url;
                    }else{
                        toaster('Info',data.msg,'info');
                    }

                },
                error: function (data) {

                    if(typeof data.responseJSON.errors !== 'undefined'){
                        const keys = Object.keys(data.responseJSON.errors);
                        keys.forEach(x=>{
                            toaster('Error',data.responseJSON.errors[x][0],'error');
                        });
                    }else{
                        toaster('Error',data.responseJSON.message,'error');
                    }
                }
            })
        }
        var cart_items = [];
        function LoadcartItems(response) {
            $('.ttl_amount').text(response.data.ttl_amount+' $');
            if(response.data.ttl_amount > 0){
                $('.cart-items').html(`<i class="fa fa-shopping-cart"></i> <sup class="badge bg-danger"><small>${response.data.ttl_amount} $</small></sup>`)
            }else{
                $('.cart-items').html(`<i class="fa fa-shopping-cart"></i></span>`)
            }
            $('.cart-body').empty();
            if(response.data.donations.length){
                cart_items = response.data.cart;
                response.data.donations.forEach(donation=>{
                    $('.cart-body').append(`<tr class="cartItemListing">
                                                                <td  class="cartItemSelection">
                                                                    <div class="truncate">${donation.deceased_first_name} ${donation.deceased_last_name}</div>
                                                                </td>
                                                                <td  style="text-align: right" class="editableAmount" id="editableAmount-${donation.uid}">${cart_items[donation.uid]} $</td>
                                                                <td class=" edit-holder" style="min-width: 100px;">
                                                                    <button type="button" uid="${donation.uid}" amount="${cart_items[donation.uid]}" action="edit" id="edit-id-${donation.uid}" href="javascript:;"  class="cartItemEdit"> <i class="edit-table fa fa-pencil"></i> </button>&nbsp;
                                                                    <button type="button" uid="${donation.uid}" amount="${cart_items[donation.uid]}" id="delete-id-${donation.uid}" href="javascript:;" class="cartItemRemove"> <i class="edit-table fa fa-trash"></i> </button>&nbsp;

                                                                </td>
                                                            </tr>`)
                });
            }
        }
        function loadCart(){
            $.ajax({
                type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
                url         : `/get-cart`, // the url where we want to POST
                data        : {},
                processData : false,
                contentType : false,
                cache       : false,
                headers     : {
                    'X-CSRF-TOKEN': jQuery('meta[name="csrf-token"]').attr('content')
                },
                success: function (response) {
                    if(response.status == 'success'){
                        LoadcartItems(response);
                        //toaster('Success','Item added to cart.','success');
                    }
                    else{
                        toaster('Error',response.msg,'error');
                    }
                },
                error: function (data) {
                    toaster('Error',data.responseJSON.message,'error');
                }
            })
        }

        $(document).ready(function () {
            $(document).on('keydown','.nbrOnly',function (e) {
                var key = e.keyCode;
                if (!( (key >= 48 && key <= 57) || (key >= 37 && key <= 40) || (key == 8) )) {
                    e.preventDefault();
                }
            });
            $(document).on('keydown','.txtOnly',function (e) {
                var key = e.keyCode;
                if (!((key == 8) || (key == 32) || (key >= 16 && key <= 18)|| (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
                    e.preventDefault();
                }
            });
            $.LoadingOverlay("hide");
        });
    </script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html><?php /**PATH E:\wamp\www\DEMO\arbituary\laravel\resources\views/layouts/public.blade.php ENDPATH**/ ?>