

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Designs</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Designs</li>
    </ol>
    <div class="card-header">
        <div class="row">
            <div class="col-12 text-right" style="text-align: right">
                <a class="btn btn-sm btn-dark" href="<?php echo e(route('admin.design.create')); ?>">New Design</a>
            </div>
        </div>
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                <tr>
                    <th>No#</th>
                    <th>design Title</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($row->title); ?></td>
                        <td><img height="50" src="<?php echo e(file_exists(storage_path('app/public/designs/'.$row->image)) ?  url('storage/designs/'.$row->image): asset('images/12.jpg')); ?>"></td>
                        <td>
                            <a class="btn btn-sm btn-dark"  href="<?php echo e(route('admin.design.show',['id'=>$row->id])); ?>">Edit</a>

                       </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\DEMO\arbituary\laravel\resources\views/admin/designs/index.blade.php ENDPATH**/ ?>