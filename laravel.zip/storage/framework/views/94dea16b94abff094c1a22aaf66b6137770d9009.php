
<?php $__env->startPush('css'); ?>
    <style>
        .card-header {
            background-color:  #232323;
            color: #fff !important;
        }
        .card-header h4 {
            color: #fff !important;
        }
        .card-body {
             padding: 0px !important;

        }
        .table {
             margin-bottom: 0rem !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Title -->
    <section class="page-title" style="background-image: url(<?php echo e(file_exists(storage_path('app/public/site_settings/'.$site->obituary_page_cover_image)) ?  url('storage/site_settings/'.$site->obituary_page_cover_image): asset('images/12.png')); ?>);">
        <div class="auto-container">
            <div class="content-box">
                <div class="title">
                    <h1><?php echo e(ucfirst($obituary->deceased_first_name)); ?> <?php echo e($obituary->deceased_last_name); ?> payments details</h1>
                </div>



            </div>
        </div>
    </section>
    <!-- End Page Title -->


    <!-- sidebar-page-container -->
    <section class="sidebar-page-container">
        <div class="auto-container">
            <div class="row">
                <div class="col-md-6 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-12"><h4>Contributor Payment Details</h4></div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th>Contributor Name</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: center"><?php echo e($row->deceased_first_name); ?> <?php echo e($row->user_name); ?></td>
                                        <td style="text-align: center"><?php echo e($row->amount); ?>$</td>
                                        <td style="text-align: center"><?php echo e(date('Y-m-d H:i', strtotime($row->created_at))); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-12"><h4>Released Payment Details</h4></div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Invoice</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $releasedpayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: center"><?php echo e($row->amount); ?>$</td>
                                        <td style="text-align: center"><?php echo e(date('Y-m-d H:i', strtotime($row->created_at))); ?></td>
                                        <td style="text-align: center"><a download href="<?php echo e(url('storage/deceased_picture/'.$obituary->deceased_picture)); ?>">Download</a> </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\DEMO\arbituary\laravel\resources\views/obituary/payments.blade.php ENDPATH**/ ?>