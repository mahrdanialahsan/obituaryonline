
<?php $__env->startPush('css'); ?>
    <style>

        .nav-pills .nav-link.active, .nav-pills .show > .nav-link {
            color: #fff;
            background-color:  #232323;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Title -->
    <section class="page-title" style="background-image: url(<?php echo e(file_exists(storage_path('app/public/site_settings/'.$site->obituary_page_cover_image)) ?  url('storage/site_settings/'.$site->obituary_page_cover_image): asset('images/12.png')); ?>);">
        <div class="auto-container">
            <div class="content-box">
                <div class="title">
                    <h1>My Obituaries</h1>
                </div>



            </div>
        </div>
    </section>
    <!-- End Page Title -->


    <!-- sidebar-page-container -->
    <section class="sidebar-page-container">
        <div class="auto-container">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header" style="background-color:  #232323;">
                            <ul class="nav nav-pills">
                                <li class="nav-item">
                                    <a class="nav-link active" data-toggle="pill" href="#Draft" role="tab" aria-controls="pills-Draft" aria-selected="true">Draft <span class="badge bg-secondary"><?php echo e(collect($obituaries['draft'])->count()); ?></span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#Pending" role="tab" aria-controls="pills-Pending" aria-selected="true">Pending <span class="badge bg-secondary"><?php echo e(collect($obituaries['pending'])->count()); ?></span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#Approved" role="tab" aria-controls="pills-Approved" aria-selected="false">Approved <span class="badge bg-secondary"><?php echo e(collect($obituaries['approved'])->count()); ?></span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#Rejected" role="tab" aria-controls="pills-Rejected" aria-selected="false">Rejected <span class="badge bg-secondary"><?php echo e(collect($obituaries['rejected'])->count()); ?></span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="pill" href="#Payment" role="tab" aria-controls="pills-Payment" aria-selected="false">Payments <span class="badge bg-secondary"><?php echo e(collect($obituaries['all'])->count()); ?></span></a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body">

                            <div class="tab-content mt-3">
                            <div class="tab-pane fade show active" id="Draft" role="tabpanel" aria-labelledby="Draft-tab">
                                <div class="search-result__gallery-flex gallery--flex gallery--flex-fill-empty" id="searchlisting">
                                    <?php if(collect($obituaries['draft'])->count()==0): ?>
                                        <div class="alert alert-warning" style="width: 100%;">
                                            No draft obituary found.
                                        </div>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $obituaries['draft']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obituary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card--flex card">
                                            <div class="card__head">
                                                <div class="gradient-over-image">
                                                    <div class="gradient-over-image__image  gradient-over-image__image--bg" style="background-image:url(<?php echo e(url('storage/deceased_picture/'.$obituary->deceased_picture)); ?>)"></div>
                                                </div>
                                            </div>
                                            <div class="card__body">
                                                <div class="media-obj">
                                                    <p class="body-txt body-txt--smaller body-txt--no-letter-space font-mid-grey break-word">  <span class="bold break-word">In loving memory of </span></p>
                                                    <h2 class="card__title truncate break-word"><a href="<?php echo e(route('obituary.details',['id'=>$obituary->uid])); ?>"><?php echo e($obituary->deceased_name); ?></a></h2>
                                                    <p class="body-txt body-txt--smaller body-txt--no-letter-space font-mid-grey break-word"> by <span class="bold break-word">JL KAH for children society </span></p>
                                                </div>
                                                <div class="media-obj mt-10">
                                                    <div class="media-obj__main media-obj__main--small-spacing body-txt body-txt--small" align="center">
                                                       <strong>Age:</strong><?php echo e(getAge($obituary->date_of_birth,$obituary->date_of_death)); ?>

                                                    </div>
                                                </div>
                                                <div class="media-obj mt-10">
                                                    <div class="media-obj__main media-obj__main--small-spacing body-txt body-txt--small" align="center">
                                                        Passed away peacefully on <?php echo e(date('d F Y',strtotime($obituary->date_of_death))); ?>

                                                    </div>
                                                </div>
                                                <div class="card__cta">
                                                    <a href="<?php echo e(route('obituary.show',['id'=>$obituary->uid])); ?>" class=" btn-ghost clearfix triggerDonateNow11 impact-message button button--small button--full " id="user-input-holder"> Edit</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="Pending" role="tabpanel" aria-labelledby="Pending-tab">
                                <div class="search-result__gallery-flex gallery--flex gallery--flex-fill-empty" id="searchlisting">
                                    <?php if(collect($obituaries['pending'])->count()==0): ?>
                                        <div class="alert alert-warning" style="width: 100%;">
                                            No pending obituary found.
                                        </div>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $obituaries['pending']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obituary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card--flex card">
                                            <div class="card__head">
                                                <div class="gradient-over-image">
                                                    <div class="gradient-over-image__image  gradient-over-image__image--bg" style="background-image:url(<?php echo e(url('storage/deceased_picture/'.$obituary->deceased_picture)); ?>)"></div>
                                                </div>
                                            </div>
                                            <div class="card__body">
                                                <div class="media-obj">
                                                    <p class="body-txt body-txt--smaller body-txt--no-letter-space font-mid-grey break-word">  <span class="bold break-word">In loving memory of </span></p>
                                                    <h2 class="card__title truncate break-word"><a href="<?php echo e(route('obituary.details',['id'=>$obituary->uid])); ?>"><?php echo e($obituary->deceased_name); ?></a></h2>
                                                    <p class="body-txt body-txt--smaller body-txt--no-letter-space font-mid-grey break-word"> by <span class="bold break-word">JL KAH for children society </span></p>
                                                </div>
                                                <div class="media-obj mt-10">
                                                    <div class="media-obj__main media-obj__main--small-spacing body-txt body-txt--small" align="center">

                                                        <strong>Age:</strong><?php echo e(getAge($obituary->date_of_birth,$obituary->date_of_death)); ?>

                                                    </div>
                                                </div>
                                                <div class="media-obj mt-10">
                                                    <div class="media-obj__main media-obj__main--small-spacing body-txt body-txt--small" align="center">
                                                        Passed away peacefully on <?php echo e(date('d F Y',strtotime($obituary->date_of_death))); ?>

                                                    </div>
                                                </div>
                                                <div class="card__cta">
                                                    <a href="<?php echo e(route('obituary.show',['id'=>$obituary->uid])); ?>" class=" btn-ghost clearfix triggerDonateNow1 impact-message button button--small button--full " id="user-input-holder"> Edit</a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="Approved" role="tabpanel" aria-labelledby="Approved-tab">
                                <div class="search-result__gallery-flex gallery--flex gallery--flex-fill-empty" id="searchlisting">
                                    <?php if(collect($obituaries['approved'])->count()==0): ?>
                                        <div class="alert alert-warning" style="width: 100%;">
                                            No approved obituary found.
                                        </div>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $obituaries['approved']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obituary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card--flex card">
                                            <div class="card__head">
                                                <div class="gradient-over-image">
                                                    <div class="gradient-over-image__image  gradient-over-image__image--bg" style="background-image:url(<?php echo e(url('storage/deceased_picture/'.$obituary->deceased_picture)); ?>)"></div>
                                                </div>
                                            </div>
                                            <div class="card__body">
                                                <div class="media-obj">
                                                    <p class="body-txt body-txt--smaller body-txt--no-letter-space font-mid-grey break-word">  <span class="bold break-word">In loving memory of </span></p>
                                                    <h2 class="card__title truncate break-word"><a href="<?php echo e(route('obituary.details',['id'=>$obituary->uid])); ?>"><?php echo e($obituary->deceased_name); ?></a></h2>
                                                    <p class="body-txt body-txt--smaller body-txt--no-letter-space font-mid-grey break-word"> by <span class="bold break-word">JL KAH for children society </span></p>
                                                </div>
                                                <div class="media-obj mt-10">
                                                    <div class="media-obj__main media-obj__main--small-spacing body-txt body-txt--small" align="center">

                                                        <strong>Age:</strong><?php echo e(getAge($obituary->date_of_birth,$obituary->date_of_death)); ?>

                                                    </div>
                                                </div>
                                                <div class="media-obj mt-10">
                                                    <div class="media-obj__main media-obj__main--small-spacing body-txt body-txt--small" align="center">
                                                        Passed away peacefully on <?php echo e(date('d F Y',strtotime($obituary->date_of_death))); ?>

                                                    </div>
                                                </div>
    
    
    
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="Rejected" role="tabpanel" aria-labelledby="Rejected-tab">
                                <div class="search-result__gallery-flex gallery--flex gallery--flex-fill-empty" id="searchlisting">
                                    <?php if(collect($obituaries['rejected'])->count()==0): ?>
                                        <div class="alert alert-warning" style="width: 100%;">
                                            No rejected obituary found.
                                        </div>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $obituaries['rejected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obituary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card--flex card">
                                            <div class="card__head">
                                                <div class="gradient-over-image">
                                                    <div class="gradient-over-image__image  gradient-over-image__image--bg" style="background-image:url(<?php echo e(url('storage/deceased_picture/'.$obituary->deceased_picture)); ?>)"></div>
                                                </div>
                                            </div>
                                            <div class="card__body">
                                                <div class="media-obj">
                                                    <p class="body-txt body-txt--smaller body-txt--no-letter-space font-mid-grey break-word">  <span class="bold break-word">In loving memory of </span></p>
                                                    <h2 class="card__title truncate break-word"><a href="<?php echo e(route('obituary.details',['id'=>$obituary->uid])); ?>"><?php echo e($obituary->deceased_name); ?></a></h2>
                                                    <p class="body-txt body-txt--smaller body-txt--no-letter-space font-mid-grey break-word"> by <span class="bold break-word">JL KAH for children society </span></p>
                                                </div>
                                                <div class="media-obj mt-10">
                                                    <div class="media-obj__main media-obj__main--small-spacing body-txt body-txt--small" align="center">

                                                        <strong>Age:</strong><?php echo e(getAge($obituary->date_of_birth,$obituary->date_of_death)); ?>

                                                    </div>
                                                </div>
                                                <div class="media-obj mt-10">
                                                    <div class="media-obj__main media-obj__main--small-spacing body-txt body-txt--small" align="center">
                                                        Passed away peacefully on <?php echo e(date('d F Y',strtotime($obituary->date_of_death))); ?>

                                                    </div>
                                                </div>
    
    
    
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                                <div class="tab-pane fade" id="Payment" role="tabpanel" aria-labelledby="Payment-tab">
                                    <div class="search-result__gallery-flex gallery--flex gallery--flex-fill-empty" id="searchlisting">
                                        <?php if(collect($obituaries['all'])->count()==0): ?>
                                            <div class="alert alert-warning" style="width: 100%;">
                                                No  obituary found.
                                            </div>
                                        <?php else: ?>

                                                <table class="table table-bordered">
                                                    <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Total Amount</th>
                                                        <th>Total Received</th>
                                                        <th>Details</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php $__currentLoopData = $obituaries['all']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obituary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><a href="<?php echo e(route('obituary.details',['id'=>$obituary->uid])); ?>"><?php echo e($obituary->deceased_first_name); ?> <?php echo e($obituary->deceased_last_name); ?></a></td>
                                                            <td style="text-align: right"><?php echo e($obituary->total_donation); ?>$</td>
                                                            <td style="text-align: right"><?php echo e($obituary->total_paid); ?>$</td>
                                                            <td><a href="<?php echo e(route('obituary.payments',['id'=>$obituary->uid])); ?>"> View</a> </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th style="text-align: right"><?php echo e(collect($obituaries['all'])->sum('total_donation')); ?>$</th>
                                                            <th style="text-align: right"><?php echo e(collect($obituaries['all'])->sum('total_paid')); ?>$</th>
                                                            <th>-</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                        <?php endif; ?>
                                    </div>
                                </div>
                        </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp\www\DEMO\arbituary\laravel\resources\views/obituary/index.blade.php ENDPATH**/ ?>