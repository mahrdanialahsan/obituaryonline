<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RelationType extends Model
{
    //
    protected $table = 'relation_type';
    protected $fillable = ['title','status'];
}
