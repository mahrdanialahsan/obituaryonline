<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ObituaryPayments extends Model
{
    //
    protected $table = 'obituary_payments';
    protected $guarded = [];
}
